package adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T> {

	protected SingleLinkedListNode<T> head;

	public SingleLinkedListImpl() {
		this.head = new SingleLinkedListNode<T>();
	}

	@Override
	public boolean isEmpty() {
		return (this.head.isNIL());
	}

	@Override
	public int size() {
		int contador = 0;
		SingleLinkedListNode<T> auxiliar = this.head; //Variavel que vai percorrendo os nos (seu valor vai sendo cada no, ate que seja um sentinela, saindo do laco), ate achar um no sentinela
		while(!auxiliar.isNIL()){
			auxiliar = auxiliar.next;
			contador += 1;
		}
		return contador;
	}

	@Override
	public T search(T element) {
		SingleLinkedListNode<T> auxiliar = this.head; //Variavel que vai percorrendo os nos

		while(auxiliar.isNIL() == false && auxiliar.getData() != element){
			auxiliar = auxiliar.next;
		}
		return auxiliar.getData();
		
	}

	@Override
	public void insert(T element) {
		if(element != null){
			SingleLinkedListNode<T> auxiliar = this.head; //Variavel que vai percorrendo os nos.
			
			//Trata o caso de o head ser no sentinela, ou seja, lista vazia.
			if(auxiliar.isNIL()){
				SingleLinkedListNode<T> novoNo = new SingleLinkedListNode<T>(element, auxiliar);
				this.head = novoNo;
			
			}else{ //Caso a lista nao seja vazia: Percorre ate achar o ultimo elemento da linkedList, ou seja, ultimo elemento q n � no sentinela.
				
				while(!auxiliar.getNext().isNIL()){
					auxiliar = auxiliar.getNext();
				}
				SingleLinkedListNode<T> novoNo = new SingleLinkedListNode<T>(element, auxiliar.getNext());
				auxiliar.next = novoNo;	
			}
			
			
		}
	}

	@Override
	public void remove(T element) {
		//Caso o primeiro elemento seja o elemento a ser removido:
		if(this.head.getData() == element){
			this.head = this.head.getNext();
		
		}else{
			//Anterior e auxiliar sao variaveis que funcionam como se fossem indices i e j caminhando em um array.
			SingleLinkedListNode<T> auxiliar = this.head; //Variavel que percorre os nos da linkedList //Auxiliar representa o elemento em questao que pode ser removido
			SingleLinkedListNode<T> anterior = this.head; //Anterior representa o elemento anterior ao auxiliar
			
			while(!(auxiliar.getNext().isNIL()) && auxiliar.getData() != element){
				anterior = auxiliar;
				auxiliar = auxiliar.getNext();
			}
			
			if(!auxiliar.isNIL()){
				anterior.next = auxiliar.next;
			}
		}
		
		
	}

	@Override
	public T[] toArray() {
		T[] array = (T[]) new Object[this.size()]; 
		SingleLinkedListNode<T> auxiliar = this.head;
		int contador = 0;
		while(!auxiliar.isNIL()){
			array[contador] = auxiliar.getData();
			auxiliar = auxiliar.getNext();
			contador = contador + 1;
		}
		return array;
	}

	public SingleLinkedListNode<T> getHead() {
		return head;
	}

	public void setHead(SingleLinkedListNode<T> head) {
		this.head = head;
	}

}
