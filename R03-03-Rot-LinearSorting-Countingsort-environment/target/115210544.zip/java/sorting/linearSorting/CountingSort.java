package sorting.linearSorting;

import sorting.AbstractSorting;

/**
 * Classe que implementa a estratégia de Counting Sort vista em sala. Procure
 * evitar desperdicio de memoria alocando o array de contadores com o tamanho
 * sendo o máximo inteiro presente no array a ser ordenado.
 * 
 */
public class CountingSort extends AbstractSorting<Integer> {

	@Override
	public void sort(Integer[] array, int leftIndex, int rightIndex) {
		Integer[] auxiliar = new Integer[array.length]; //Esse ser� o array auxiliar, que conter� a resposta final.
		
		//Trecho de c�digo para descobrir qual � o maximo inteiro presente.
		int maxInteiro = 0;
		for(int i = leftIndex; i <= rightIndex; i++){
			if (array[i] >= maxInteiro)
				maxInteiro = array[i];
		}
		
		//inicializa um array de contadores com o tamanho sendo o maximo inteiro presente no array da entrada +1 por causa do 0
		//e inicializa cada posicao com 0.
		Integer[] arrayContadores = new Integer[maxInteiro+1];
		for (Integer i = 0; i < arrayContadores.length; i++){
			arrayContadores[i] = 0;
		}
		
		//Contagem dos elementos
		for (int i = leftIndex; i < rightIndex+1; i++){
			arrayContadores[array[i]]+=1;
		}
		//Soma dos prefixos
		for (int i = 1; i < arrayContadores.length; i++){
			arrayContadores[i] += arrayContadores[i-1];
		}
		//Colocando o array recebido como um array ordenado usando o array auxiliar.
		//Percorremos de tr�s pra frente - ordenacao estavel.
		for (int i = rightIndex; i >= leftIndex; i--){
			arrayContadores[array[i]]--;
			auxiliar[arrayContadores[array[i]]] = array[i];
		}
		//Transcreve os elementos do array auxiliar(ordenado) para o array normal(desordenado).
		for (int i = leftIndex; i <= rightIndex; i++){
			array[i] = auxiliar[i];
		}
		
		
		
		
		
	}

}
